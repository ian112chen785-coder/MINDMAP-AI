import { Project, FlowNode } from '../types';

const DB_NAME = 'FlowMindDB';
const DB_VERSION = 1;
const STORE_PROJECTS = 'projects';
const STORE_NODES = 'nodes';

const openDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_PROJECTS)) {
        db.createObjectStore(STORE_PROJECTS, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_NODES)) {
        const nodeStore = db.createObjectStore(STORE_NODES, { keyPath: 'id' });
        nodeStore.createIndex('projectId', 'projectId', { unique: false });
        nodeStore.createIndex('parentId', 'parentId', { unique: false });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
};

export const dbService = {
  async getProjects(): Promise<Project[]> {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_PROJECTS, 'readonly');
      const store = tx.objectStore(STORE_PROJECTS);
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  },

  async addProject(project: Project): Promise<void> {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_PROJECTS, 'readwrite');
      const store = tx.objectStore(STORE_PROJECTS);
      const request = store.put(project);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  },

  async deleteProject(id: string): Promise<void> {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction([STORE_PROJECTS, STORE_NODES], 'readwrite');
      
      // Delete project
      const projectStore = tx.objectStore(STORE_PROJECTS);
      projectStore.delete(id);

      // Delete associated nodes (Manual scan as IDB doesn't cascade)
      const nodeStore = tx.objectStore(STORE_NODES);
      const index = nodeStore.index('projectId');
      const nodeRequest = index.openCursor(IDBKeyRange.only(id));
      
      nodeRequest.onsuccess = (e) => {
        const cursor = (e.target as IDBRequest).result as IDBCursor;
        if (cursor) {
          cursor.delete();
          cursor.continue();
        }
      };

      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  },

  async getNodesByProject(projectId: string): Promise<FlowNode[]> {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NODES, 'readonly');
      const store = tx.objectStore(STORE_NODES);
      const index = store.index('projectId');
      const request = index.getAll(projectId);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  },

  async saveNode(node: FlowNode): Promise<void> {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NODES, 'readwrite');
      const store = tx.objectStore(STORE_NODES);
      const request = store.put(node);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  },

  async deleteNode(nodeId: string): Promise<void> {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NODES, 'readwrite');
      const store = tx.objectStore(STORE_NODES);
      const request = store.delete(nodeId);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  },

  // Export all data
  async exportData(): Promise<string> {
    const projects = await this.getProjects();
    const db = await openDB();
    
    // Get all nodes
    const nodes = await new Promise<FlowNode[]>((resolve, reject) => {
        const tx = db.transaction(STORE_NODES, 'readonly');
        const store = tx.objectStore(STORE_NODES);
        const request = store.getAll();
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
    });

    const data = {
        projects,
        nodes,
        version: 1,
        exportedAt: Date.now()
    };
    return JSON.stringify(data);
  },

  // Import data (Merge strategy)
  async importData(jsonString: string): Promise<void> {
    try {
        const data = JSON.parse(jsonString);
        if (!data.projects || !data.nodes) throw new Error("Invalid format");

        const db = await openDB();
        const tx = db.transaction([STORE_PROJECTS, STORE_NODES], 'readwrite');
        const projectStore = tx.objectStore(STORE_PROJECTS);
        const nodeStore = tx.objectStore(STORE_NODES);

        data.projects.forEach((p: Project) => projectStore.put(p));
        data.nodes.forEach((n: FlowNode) => nodeStore.put(n));

        return new Promise((resolve, reject) => {
            tx.oncomplete = () => resolve();
            tx.onerror = () => reject(tx.error);
        });
    } catch (e) {
        console.error("Import failed", e);
        throw e;
    }
  }
};