import { GoogleGenAI, Type } from "@google/genai";
import { FlowNode, NodeType } from "../types";

const initGenAI = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key not found");
  }
  return new GoogleGenAI({ apiKey });
};

export const geminiService = {
  // Generate a structure from files or text
  async generateMapFromContent(content: string, projectId: string, imageBase64?: string): Promise<FlowNode[]> {
    const ai = initGenAI();
    
    // Schema definition for the tree structure
    const responseSchema = {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          label: { type: Type.STRING },
          description: { type: Type.STRING },
          children: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                label: { type: Type.STRING },
                description: { type: Type.STRING },
              }
            }
          }
        },
        required: ['label'],
      }
    };

    const promptText = `請分析以下內容並生成一個包含主要階段（根節點）和子任務（子節點）的專案結構。
    內容：${content.substring(0, 10000)}...
    
    請以繁體中文返回主要節點列表，每個節點包含子節點列表。`;

    const parts: any[] = [{ text: promptText }];
    if (imageBase64) {
      parts.push({
        inlineData: {
          mimeType: 'image/jpeg',
          data: imageBase64.split(',')[1] // remove data:image/jpeg;base64, prefix
        }
      });
    }

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts },
        config: {
          responseMimeType: 'application/json',
          responseSchema: responseSchema,
        }
      });

      const rawData = JSON.parse(response.text || '[]');
      
      // Convert raw AI response to FlowNodes
      const nodes: FlowNode[] = [];
      const timestamp = Date.now();
      
      let xOffset = 0;

      // Create a virtual root or handle multi-root
      // For this app logic, let's create separate trees per item in array, all at level 0 (or 1 if we have a master root)
      // Since the app allows drilling, we usually want one main entry, but here we can add multiple level 0 nodes.
      
      rawData.forEach((mainItem: any, i: number) => {
        const rootId = `ai-${timestamp}-${i}`;
        
        // Level 0 Node
        nodes.push({
          id: rootId,
          projectId,
          parentId: null,
          label: mainItem.label,
          description: mainItem.description || '',
          type: NodeType.PROCESS,
          level: 0,
          x: xOffset,
          y: 0,
          width: 180,
          height: 80,
          color: '#8b5cf6' // Violet for AI nodes
        });

        // Level 1 Children
        if (mainItem.children) {
            mainItem.children.forEach((child: any, j: number) => {
                nodes.push({
                    id: `ai-${timestamp}-${i}-${j}`,
                    projectId,
                    parentId: rootId,
                    label: child.label,
                    description: child.description || '',
                    type: NodeType.PROCESS,
                    level: 1,
                    x: xOffset + (j * 200) - ((mainItem.children.length * 200)/2), // Spread children
                    y: 300,
                    width: 160,
                    height: 70
                });
            });
        }
        xOffset += 400;
      });

      return nodes;

    } catch (error) {
      console.error("AI Generation Failed:", error);
      throw error;
    }
  },

  async askAdvice(contextNodes: FlowNode[], query: string): Promise<string> {
    const ai = initGenAI();
    
    // Flatten context for the AI
    const contextStr = contextNodes.map(n => 
      `[層級 ${n.level}] ${n.label}: ${n.description || ''}`
    ).join('\n');

    const prompt = `你是一個專業的專案管理助手。
    目前的專案結構 (節點)：
    ${contextStr}

    用戶問題：${query}
    
    請針對流程圖或心智圖提供簡潔、有幫助的繁體中文建議。`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt
        });
        return response.text || "目前無法生成建議。";
    } catch (error) {
        console.error("AI Advice Failed", error);
        return "連接 AI 助手時發生錯誤。";
    }
  }
};