import React, { useState } from 'react';
import { Project } from '../types';
import { Plus, Trash2, FolderOpen, ArrowRight, Settings, Download, Upload, X } from 'lucide-react';
import { dbService } from '../services/dbService';

interface ProjectListProps {
  projects: Project[];
  onOpen: (p: Project) => void;
  onCreate: (name: string, desc: string) => void;
  onDelete: (id: string) => void;
}

export const ProjectList: React.FC<ProjectListProps> = ({ projects, onOpen, onCreate, onDelete }) => {
  const [isCreating, setIsCreating] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newName.trim()) {
      onCreate(newName, newDesc);
      setIsCreating(false);
      setNewName('');
      setNewDesc('');
    }
  };

  const handleExport = async () => {
    try {
        const json = await dbService.exportData();
        const blob = new Blob([json], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `flowmind_backup_${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    } catch (e) {
        alert("匯出失敗");
    }
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
        try {
            const json = event.target?.result as string;
            await dbService.importData(json);
            alert("匯入成功！請重新整理頁面以檢視變更。");
            window.location.reload();
        } catch (err) {
            alert("匯入失敗：檔案格式錯誤");
        }
    };
    reader.readAsText(file);
  };

  return (
    <div className="p-8 max-w-7xl mx-auto h-full overflow-y-auto relative">
      <div className="flex justify-between items-center mb-10">
        <div>
          <h1 className="text-4xl font-extrabold tracking-tight bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">專案列表</h1>
          <p className="text-slate-500 dark:text-slate-400 mt-2 font-medium">管理您的流程圖與心智圖專案</p>
        </div>
        <div className="flex gap-3">
            <button 
              onClick={() => setIsSettingsOpen(true)}
              className="p-3 rounded-full bg-white dark:bg-zinc-800 shadow-md hover:shadow-lg text-gray-600 dark:text-gray-300 transition-all hover:scale-105"
            >
              <Settings size={20} />
            </button>
            <button 
              onClick={() => setIsCreating(true)}
              className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-6 py-3 rounded-2xl font-bold transition-all shadow-lg shadow-blue-500/30 active:scale-95 flex items-center gap-2"
            >
              <Plus size={20} />
              新增專案
            </button>
        </div>
      </div>

      {isCreating && (
        <div className="mb-8 p-6 bg-white/60 dark:bg-zinc-800/60 glass-panel rounded-3xl border border-white/40 dark:border-white/10 shadow-xl animate-in fade-in slide-in-from-top-4 backdrop-blur-xl">
          <form onSubmit={handleSubmit} className="flex flex-col gap-4 max-w-md">
            <h3 className="text-lg font-bold text-slate-800 dark:text-white">建立新專案</h3>
            <input
              autoFocus
              type="text"
              placeholder="專案名稱"
              className="px-4 py-3 rounded-xl bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-700 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
              value={newName}
              onChange={e => setNewName(e.target.value)}
            />
            <input
              type="text"
              placeholder="描述 (選填)"
              className="px-4 py-3 rounded-xl bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-700 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
              value={newDesc}
              onChange={e => setNewDesc(e.target.value)}
            />
            <div className="flex gap-2 mt-2">
                <button type="submit" className="bg-slate-900 dark:bg-white text-white dark:text-black px-6 py-2 rounded-xl font-bold hover:opacity-90 transition-opacity">建立</button>
                <button type="button" onClick={() => setIsCreating(false)} className="px-6 py-2 text-slate-500 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-xl transition-colors">取消</button>
            </div>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map(project => (
          <div 
            key={project.id} 
            className="group relative bg-white dark:bg-zinc-900 rounded-[2rem] p-6 shadow-sm hover:shadow-[0_20px_40px_rgba(0,0,0,0.1)] transition-all duration-300 border border-gray-100 dark:border-zinc-800 cursor-pointer flex flex-col justify-between h-64 hover:-translate-y-1"
            onClick={() => onOpen(project)}
          >
            <div>
              <div className="w-14 h-14 bg-gradient-to-br from-blue-100 to-purple-100 dark:from-blue-900/30 dark:to-purple-900/30 rounded-2xl flex items-center justify-center text-blue-600 dark:text-blue-400 mb-4 group-hover:scale-110 group-hover:rotate-3 transition-transform shadow-inner">
                <FolderOpen size={28} />
              </div>
              <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-2 line-clamp-1">{project.name}</h3>
              <p className="text-slate-500 dark:text-slate-400 text-sm line-clamp-3">{project.description || "無描述"}</p>
            </div>
            
            <div className="flex justify-between items-center mt-4">
              <span className="text-xs text-gray-400 font-medium bg-gray-100 dark:bg-zinc-800 px-2 py-1 rounded-lg">{new Date(project.createdAt).toLocaleDateString()}</span>
              <div className="flex gap-2">
                 <button 
                    onClick={(e) => { e.stopPropagation(); onDelete(project.id); }}
                    className="p-2 hover:bg-red-50 dark:hover:bg-red-900/20 text-gray-300 hover:text-red-500 rounded-full transition-colors"
                >
                    <Trash2 size={20} />
                </button>
                <div className="w-10 h-10 rounded-full bg-gray-50 dark:bg-zinc-800 flex items-center justify-center group-hover:bg-blue-500 group-hover:text-white transition-all shadow-sm group-hover:shadow-blue-500/40">
                    <ArrowRight size={20} />
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Settings Modal */}
      {isSettingsOpen && (
        <div className="fixed inset-0 bg-black/30 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in">
            <div className="bg-white dark:bg-zinc-900 rounded-3xl p-8 max-w-md w-full shadow-2xl border border-white/20">
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-2xl font-bold">設定 & 備份</h2>
                    <button onClick={() => setIsSettingsOpen(false)} className="p-2 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-full"><X size={20}/></button>
                </div>

                <div className="space-y-6">
                    <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-2xl border border-blue-100 dark:border-blue-800/50">
                        <h3 className="font-bold text-blue-700 dark:text-blue-300 mb-2">API 設定</h3>
                        <p className="text-sm text-blue-600/80 dark:text-blue-400/80">
                            系統自動使用環境變數中的 API Key 進行 AI 連線。無需手動輸入。
                        </p>
                    </div>

                    <div className="space-y-3">
                        <h3 className="font-bold text-gray-900 dark:text-white">資料管理</h3>
                        <button 
                            onClick={handleExport}
                            className="w-full flex items-center justify-center gap-2 bg-gray-100 dark:bg-zinc-800 hover:bg-gray-200 dark:hover:bg-zinc-700 py-3 rounded-xl font-medium transition-colors"
                        >
                            <Download size={18} />
                            匯出備份 (JSON)
                        </button>
                        
                        <div className="relative">
                            <input 
                                type="file" 
                                accept=".json"
                                onChange={handleImport}
                                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                            />
                            <button className="w-full flex items-center justify-center gap-2 bg-gray-100 dark:bg-zinc-800 hover:bg-gray-200 dark:hover:bg-zinc-700 py-3 rounded-xl font-medium transition-colors">
                                <Upload size={18} />
                                匯入還原
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};