import React, { memo, useState, useEffect, useRef } from 'react';
import { FlowNode } from '../types';
import { GripVertical, ChevronRight, CornerDownRight, Trash2, ArrowDownRight } from 'lucide-react';

interface NodeProps {
  node: FlowNode;
  isSelected: boolean;
  isLinkSource: boolean;
  isEditing: boolean; // New prop for individual edit mode
  
  // Modes
  mode: 'view' | 'batch_edit' | 'batch_delete';
  isSelectedForDelete: boolean;
  
  // Actions
  onSelect: (node: FlowNode) => void;
  onDragStart: (e: React.MouseEvent, node: FlowNode) => void;
  onResizeStart: (e: React.MouseEvent, node: FlowNode) => void;
  onDrillDown: (node: FlowNode) => void;
  onGoUp: () => void;
  onDoubleClick: (node: FlowNode) => void;
  onLabelChange: (node: FlowNode, newLabel: string) => void;
  onEditEnd: () => void; // Callback when editing finishes
  onToggleDeleteSelect: (node: FlowNode) => void;
  isParent: boolean; 
  isFocus: boolean; 
}

export const Node: React.FC<NodeProps> = memo(({ 
  node, 
  isSelected,
  isLinkSource,
  isEditing,
  mode,
  isSelectedForDelete,
  onSelect, 
  onDragStart,
  onResizeStart,
  onDrillDown,
  onGoUp,
  onDoubleClick,
  onLabelChange,
  onEditEnd,
  onToggleDeleteSelect,
  isParent,
  isFocus 
}) => {
  
  const [localLabel, setLocalLabel] = useState(node.label);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Sync state when prop changes
  useEffect(() => { setLocalLabel(node.label); }, [node.label]);

  // Auto-focus textarea when entering edit mode
  useEffect(() => {
    if ((isEditing || (mode === 'batch_edit' && !isParent)) && textareaRef.current) {
        textareaRef.current.focus();
        textareaRef.current.select();
    }
  }, [isEditing, mode, isParent]);

  // Styles
  const baseClasses = `absolute flex flex-col items-center justify-center p-4 rounded-3xl transition-shadow duration-200 cursor-pointer select-none group will-change-transform`;
  
  let visualClasses = "";
  
  if (mode === 'batch_delete') {
      if (isSelectedForDelete) {
          visualClasses = "bg-red-100 dark:bg-red-900/40 border-2 border-red-500 shadow-[0_0_15px_rgba(239,68,68,0.5)] scale-95 z-40";
      } else {
          visualClasses = "bg-white dark:bg-zinc-800 border-2 border-dashed border-red-300 dark:border-red-800 opacity-90 hover:opacity-100 hover:scale-105";
      }
  } else if (isSelected || isLinkSource || isEditing) {
    visualClasses = "ring-4 ring-purple-400/50 shadow-[0_10px_30px_rgba(168,85,247,0.4)] bg-white dark:bg-zinc-800 z-50 scale-105";
  } else if (isFocus) {
    visualClasses = "ring-4 ring-blue-400/30 shadow-[0_20px_40px_rgba(59,130,246,0.3)] bg-gradient-to-br from-white to-blue-50 dark:from-zinc-800 dark:to-zinc-900 scale-110 z-40 border-2 border-blue-500/20";
  } else if (isParent) {
    visualClasses = "bg-gray-50/80 dark:bg-zinc-900/50 border-2 border-dashed border-gray-300 dark:border-zinc-700 opacity-60 scale-90 blur-[1px] hover:blur-0 transition-all";
  } else {
    visualClasses = "bg-white dark:bg-zinc-800 shadow-[0_8px_16px_rgba(0,0,0,0.1)] hover:shadow-[0_12px_24px_rgba(0,0,0,0.15)] hover:-translate-y-1 border border-white/20 dark:border-white/5";
  }

  const hasCustomColor = !!node.color && mode !== 'batch_delete' && !isEditing;
  const style: React.CSSProperties = {
    left: node.x,
    top: node.y,
    width: node.width || 180,
    height: node.height || 80,
    backgroundColor: hasCustomColor ? node.color : undefined,
    color: hasCustomColor ? '#fff' : undefined,
  };

  const handleMouseDown = (e: React.MouseEvent) => {
      e.stopPropagation();
      if (mode === 'batch_delete') {
          onToggleDeleteSelect(node);
      } else {
          onSelect(node);
          onDragStart(e, node);
      }
  };

  // Determine if we are in any edit state for this node
  const isInEditMode = isEditing || (mode === 'batch_edit' && !isParent);

  return (
    <div 
      className={`${baseClasses} ${visualClasses}`}
      style={style}
      onMouseDown={handleMouseDown}
      onDoubleClick={(e) => {
        e.stopPropagation();
        if (mode === 'view') onDoubleClick(node);
      }}
      onClick={(e) => e.stopPropagation()}
    >
      {/* Delete Badge */}
      {mode === 'batch_delete' && isSelectedForDelete && (
          <div className="absolute -top-3 -right-3 bg-red-500 text-white p-1.5 rounded-full shadow-md z-50 animate-bounce">
              <Trash2 size={16} />
          </div>
      )}

      {/* Glossy highlight */}
      {!hasCustomColor && !isParent && mode !== 'batch_delete' && !isInEditMode && (
         <div className="absolute inset-x-4 top-0 h-[1px] bg-gradient-to-r from-transparent via-white to-transparent opacity-50"></div>
      )}

      {/* Drag Handle (Visual Only) */}
      {mode === 'view' && !isParent && !isInEditMode && (
        <div className="absolute left-2 text-gray-300 dark:text-gray-600 opacity-0 group-hover:opacity-100 cursor-grab active:cursor-grabbing transition-opacity">
            <GripVertical size={16} />
        </div>
      )}

      {/* Content Area */}
      <div className="flex flex-col items-center text-center w-full h-full justify-center overflow-hidden relative z-10">
        {isInEditMode ? (
            <textarea 
                ref={textareaRef}
                className="w-full h-full text-center bg-transparent border-b border-blue-300 focus:border-blue-500 focus:outline-none px-1 text-slate-800 dark:text-white resize-none"
                value={localLabel}
                onChange={(e) => setLocalLabel(e.target.value)}
                onBlur={() => {
                    if (localLabel !== node.label) onLabelChange(node, localLabel);
                    onEditEnd();
                }}
                onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        if (localLabel !== node.label) onLabelChange(node, localLabel);
                        onEditEnd();
                    }
                }}
                onMouseDown={(e) => e.stopPropagation()}
                onClick={(e) => e.stopPropagation()}
            />
        ) : (
            <span className={`font-bold tracking-tight w-full px-2 pointer-events-none whitespace-pre-wrap leading-tight break-words ${node.fontSize ? `text-[${node.fontSize}px]` : 'text-base'}`}>
                {node.label}
            </span>
        )}

        {node.description && !isInEditMode && (
          <span className={`text-[11px] truncate w-full px-2 mt-1 pointer-events-none ${hasCustomColor ? 'text-white/80' : 'text-gray-500 dark:text-gray-400'}`}>
            {node.description}
          </span>
        )}
      </div>

      {/* Resize Handle (Bottom Right) */}
      {mode === 'view' && !isParent && !isInEditMode && (
        <div 
            className="absolute bottom-1 right-1 p-1 text-gray-400 dark:text-gray-500 opacity-0 group-hover:opacity-100 cursor-nwse-resize hover:text-blue-500 transition-all z-20"
            onMouseDown={(e) => {
                e.stopPropagation();
                onResizeStart(e, node);
            }}
        >
            <ArrowDownRight size={18} strokeWidth={3} />
        </div>
      )}

      {/* Drill Down Action */}
      {!isParent && node.level < 9 && mode === 'view' && !isInEditMode && (
        <button 
            className="absolute -right-3 top-1/2 -translate-y-1/2 w-8 h-8 bg-white dark:bg-zinc-700 rounded-full shadow-lg border border-gray-100 dark:border-zinc-600 flex items-center justify-center text-gray-400 hover:bg-blue-500 hover:text-white hover:scale-110 transition-all z-20 pointer-events-auto"
            onClick={(e) => {
                e.stopPropagation();
                onDrillDown(node);
            }}
            title="進入下一層"
        >
            <ChevronRight size={16} />
        </button>
      )}

      {/* Go Up Action (Rendered inside node if needed, but we also have global button now) */}
      {isParent && (
        <button 
            className="absolute -bottom-3 left-1/2 -translate-x-1/2 w-8 h-8 bg-white dark:bg-zinc-700 rounded-full shadow-lg border border-gray-100 dark:border-zinc-600 flex items-center justify-center hover:bg-gray-100 dark:hover:bg-zinc-600 hover:scale-110 transition-all z-20 pointer-events-auto"
            onClick={(e) => {
                e.stopPropagation();
                onGoUp();
            }}
            title="返回上一層"
        >
            <CornerDownRight size={16} className="rotate-180 text-gray-500 dark:text-gray-300" />
        </button>
      )}
      
      {/* Level Badge */}
      <div className="absolute -top-2 -right-2 w-6 h-6 bg-gradient-to-br from-gray-100 to-gray-200 dark:from-zinc-700 dark:to-zinc-800 text-[10px] font-bold flex items-center justify-center rounded-full text-gray-600 dark:text-gray-300 shadow-sm border border-white dark:border-zinc-600">
        {node.level}
      </div>
    </div>
  );
});

Node.displayName = 'Node';