import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { Project, FlowNode, NodeType } from '../types';
import { dbService } from '../services/dbService';
import { Node } from './Node';
import { geminiService } from '../services/geminiService';
import { 
  Plus, Search, Bot, Moon, Sun, ChevronLeft, 
  ZoomIn, ZoomOut, Trash2, Type, 
  Upload, Sparkles, X, Link as LinkIcon, Home,
  Menu, Maximize, Minimize, Edit3, ArrowUp, Focus, Send
} from 'lucide-react';

interface MapEditorProps {
  project: Project;
  onBack: () => void;
  toggleTheme: () => void;
  isDark: boolean;
}

const NODE_COLORS = [
    '#ef4444', '#f97316', '#eab308', '#22c55e', 
    '#06b6d4', '#3b82f6', '#a855f7', '#ec4899',
];

export const MapEditor: React.FC<MapEditorProps> = ({ project, onBack, toggleTheme, isDark }) => {
  // Data State
  const [nodes, setNodes] = useState<FlowNode[]>([]);
  const [viewRootId, setViewRootId] = useState<string | null>(null);
  const [selectedNode, setSelectedNode] = useState<FlowNode | null>(null);
  
  // UI State
  const [loading, setLoading] = useState(false);
  const [scale, setScale] = useState(1);
  const [searchMode, setSearchMode] = useState<'node' | 'ai'>('node');
  const [searchQuery, setSearchQuery] = useState('');
  
  // AI Chat State
  const [aiChatOpen, setAiChatOpen] = useState(false);
  const [aiQuery, setAiQuery] = useState('');
  const [aiResponse, setAiResponse] = useState<string>('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  
  // Edit & Modes
  const [editingNodeId, setEditingNodeId] = useState<string | null>(null);
  const [isToolsOpen, setIsToolsOpen] = useState(false);
  const [mode, setMode] = useState<'view' | 'batch_edit' | 'batch_delete'>('view');
  const [deleteCandidates, setDeleteCandidates] = useState<Set<string>>(new Set());
  const [isLinking, setIsLinking] = useState(false);
  const [linkSourceId, setLinkSourceId] = useState<string | null>(null);
  const [isFullScreen, setIsFullScreen] = useState(false);
  
  // Canvas State
  const canvasRef = useRef<HTMLDivElement>(null);
  const [visualOffset, setVisualOffset] = useState({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const rafRef = useRef<number | null>(null);

  // Dragging Refs
  const dragRef = useRef<{ 
    active: boolean; 
    nodeId: string | null; 
    startX: number; 
    startY: number; 
    initX: number; 
    initY: number; 
  }>({ active: false, nodeId: null, startX: 0, startY: 0, initX: 0, initY: 0 });

  const resizeRef = useRef<{
    active: boolean;
    nodeId: string | null;
    startX: number;
    startY: number;
    initWidth: number;
    initHeight: number;
  }>({ active: false, nodeId: null, startX: 0, startY: 0, initWidth: 0, initHeight: 0 });

  const panRef = useRef<{
    active: boolean;
    startX: number;
    startY: number;
    initOffsetX: number;
    initOffsetY: number;
  }>({ active: false, startX: 0, startY: 0, initOffsetX: 0, initOffsetY: 0 });

  // Initial Load
  useEffect(() => {
    loadNodes();
    centerView();
  }, [project.id]);

  const centerView = () => {
    setVisualOffset({ x: window.innerWidth / 2 - 200, y: window.innerHeight / 2 - 200 });
  };

  const handleResetZoom = () => {
    setScale(1);
    centerView();
  };

  // Fullscreen Listener
  useEffect(() => {
      const handleFsChange = () => setIsFullScreen(!!document.fullscreenElement);
      document.addEventListener('fullscreenchange', handleFsChange);
      return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  const loadNodes = async () => {
    try {
      const data = await dbService.getNodesByProject(project.id);
      setNodes(data);
    } catch (e) {
      console.error("Failed to load nodes", e);
    }
  };

  const visibleNodes = useMemo(() => {
    if (!viewRootId) return nodes.filter(n => n.level === 0);
    const currentRoot = nodes.find(n => n.id === viewRootId);
    if (!currentRoot) return [];
    const parentNode = currentRoot.parentId ? nodes.find(n => n.id === currentRoot.parentId) : null;
    const childNodes = nodes.filter(n => n.parentId === viewRootId);
    const result = [currentRoot, ...childNodes];
    if (parentNode) result.push(parentNode);
    return result;
  }, [nodes, viewRootId]);

  const currentLevel = viewRootId ? (nodes.find(n => n.id === viewRootId)?.level || 0) : 0;
  
  // Search Logic
  const filteredNodes = useMemo(() => {
      if (!searchQuery || searchMode !== 'node') return [];
      return nodes.filter(n => n.label.toLowerCase().includes(searchQuery.toLowerCase()));
  }, [nodes, searchQuery, searchMode]);

  const handleJumpToNode = (node: FlowNode) => {
      if (node.level === 0) {
          setViewRootId(null);
      } else {
          setViewRootId(node.parentId);
      }
      
      const targetScale = 1; 
      setScale(targetScale);
      setVisualOffset({
          x: (window.innerWidth / 2) - (node.x * targetScale) - ((node.width || 180) / 2 * targetScale),
          y: (window.innerHeight / 2) - (node.y * targetScale) - ((node.height || 80) / 2 * targetScale)
      });

      setSelectedNode(node);
      setSearchQuery(''); // Close search
  };

  // AI Advice Handler
  const handleAskAi = async () => {
    if(!aiQuery.trim()) return;
    setIsAiLoading(true);
    try {
        // Context: send visible nodes to AI to understand current structure
        const context = visibleNodes.length > 0 ? visibleNodes : nodes.slice(0, 30); 
        const advice = await geminiService.askAdvice(context, aiQuery);
        setAiResponse(advice);
    } catch(e) {
        setAiResponse("發生錯誤，請檢查網路連線或稍後再試。");
    } finally {
        setIsAiLoading(false);
        setAiQuery('');
    }
  };

  // --- Mode Toggles ---

  const toggleFullScreen = () => {
      if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().catch((e) => console.error(e));
      } else {
          document.exitFullscreen();
      }
  };

  const toggleBatchEdit = () => {
      setMode(prev => prev === 'batch_edit' ? 'view' : 'batch_edit');
      setDeleteCandidates(new Set());
      setIsLinking(false);
      setSelectedNode(null);
      setEditingNodeId(null);
  };

  const toggleBatchDelete = () => {
      setMode(prev => prev === 'batch_delete' ? 'view' : 'batch_delete');
      setDeleteCandidates(new Set());
      setIsLinking(false);
      setSelectedNode(null);
      setEditingNodeId(null);
  };

  const confirmBatchDelete = async () => {
      if (deleteCandidates.size === 0) return;
      if (confirm(`確定要刪除選取的 ${deleteCandidates.size} 個節點嗎？`)) {
          const idsToRemove = Array.from(deleteCandidates);
          for (const id of idsToRemove) await dbService.deleteNode(id);
          setNodes(prev => prev.map(n => {
            if (n.outgoingIds?.some(oid => idsToRemove.includes(oid))) {
                const newIds = n.outgoingIds.filter(oid => !idsToRemove.includes(oid));
                dbService.saveNode({ ...n, outgoingIds: newIds }); 
                return { ...n, outgoingIds: newIds };
            }
            return n;
          }).filter(n => !idsToRemove.includes(n.id)));
          setDeleteCandidates(new Set());
          setMode('view');
      }
  };

  // --- Node Actions ---

  const handleAddNode = async () => {
    if (currentLevel >= 9) return; 
    const parentId = viewRootId;
    const newId = crypto.randomUUID();
    const centerX = (-visualOffset.x + window.innerWidth/2) / scale;
    const centerY = (-visualOffset.y + window.innerHeight/2) / scale;

    const newNode: FlowNode = {
      id: newId,
      projectId: project.id,
      parentId: parentId,
      label: '新節點',
      type: NodeType.PROCESS,
      level: currentLevel + (parentId ? 1 : 0),
      x: centerX + (Math.random() * 40 - 20),
      y: centerY + (Math.random() * 40 - 20),
      width: 180,
      height: 80,
      outgoingIds: []
    };
    
    if (viewRootId) {
        const root = nodes.find(n => n.id === viewRootId);
        if(root) newNode.level = root.level + 1;
    } else {
        newNode.level = 0;
    }

    await dbService.saveNode(newNode);
    setNodes(prev => [...prev, newNode]);
    setEditingNodeId(newId);
    setSelectedNode(newNode);
  };

  const handleUpdateNode = async (updatedNode: FlowNode) => {
    await dbService.saveNode(updatedNode);
    setNodes(prev => prev.map(n => n.id === updatedNode.id ? updatedNode : n));
  };

  const handleDeleteSingleNode = async () => {
    if (!selectedNode) return;
    if (confirm("確定要刪除此節點？")) {
        const id = selectedNode.id;
        await dbService.deleteNode(id);
        setNodes(prev => prev.filter(n => n.id !== id));
        setSelectedNode(null);
    }
  };

  const handleLabelChange = useCallback(async (node: FlowNode, newLabel: string) => {
      const updated = { ...node, label: newLabel };
      await dbService.saveNode(updated);
      setNodes(prev => prev.map(n => n.id === node.id ? updated : n));
  }, []);

  const handleToggleDeleteSelect = useCallback((node: FlowNode) => {
      setDeleteCandidates(prev => {
          const next = new Set(prev);
          if (next.has(node.id)) next.delete(node.id);
          else next.add(node.id);
          return next;
      });
  }, []);

  // --- Linking Logic ---
  const handleToggleLink = async (targetNode: FlowNode) => {
      if (!linkSourceId) {
          setLinkSourceId(targetNode.id);
      } else {
          if (linkSourceId === targetNode.id) {
              setLinkSourceId(null);
              return;
          }
          const sourceNode = nodes.find(n => n.id === linkSourceId);
          if (sourceNode) {
              let newOutgoing = sourceNode.outgoingIds || [];
              if (newOutgoing.includes(targetNode.id)) {
                  newOutgoing = newOutgoing.filter(id => id !== targetNode.id);
              } else {
                  newOutgoing = [...newOutgoing, targetNode.id];
              }
              await handleUpdateNode({ ...sourceNode, outgoingIds: newOutgoing });
              setLinkSourceId(null);
              setIsLinking(false);
              setMode('view');
          }
      }
  };

  // --- Interaction Handlers ---

  const handleDrillDown = useCallback((node: FlowNode) => {
    if (node.level < 9) {
        setViewRootId(node.id);
        const targetScale = 1;
        // Calculation: We want the node at 20% from the top (Upper Middle)
        // ScreenY = NodeY * Scale + OffsetY
        // OffsetY = ScreenY - NodeY * Scale
        setVisualOffset({ 
            x: (window.innerWidth / 2) - (node.x * targetScale) - ((node.width || 180) / 2 * targetScale), 
            y: (window.innerHeight * 0.2) - (node.y * targetScale)
        });
        setScale(targetScale);
        setSelectedNode(null);
        setLinkSourceId(null);
    }
  }, []);

  const handleGoUp = useCallback(() => {
    if (!viewRootId) return;
    const currentRoot = nodes.find(n => n.id === viewRootId);
    if (currentRoot && currentRoot.parentId) setViewRootId(currentRoot.parentId);
    else setViewRootId(null);
    setLinkSourceId(null);
  }, [nodes, viewRootId]);

  const handleGoRoot = useCallback(() => {
    setViewRootId(null);
    centerView();
  }, []);

  const handleMouseDownCanvas = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).tagName === 'DIV' || (e.target as HTMLElement).tagName === 'svg') {
        setIsPanning(true);
        panRef.current = { active: true, startX: e.clientX, startY: e.clientY, initOffsetX: visualOffset.x, initOffsetY: visualOffset.y };
        setSelectedNode(null);
        setEditingNodeId(null); 
    }
  };

  const handleDragNodeStart = useCallback((e: React.MouseEvent, node: FlowNode) => {
    e.stopPropagation(); 
    if (isLinking) {
        handleToggleLink(node);
        return;
    }
    if (mode === 'batch_delete') return;
    if (mode !== 'view') return; 

    dragRef.current = { active: true, nodeId: node.id, startX: e.clientX, startY: e.clientY, initX: node.x, initY: node.y };
  }, [isLinking, linkSourceId, mode]);

  const handleResizeStart = useCallback((e: React.MouseEvent, node: FlowNode) => {
      e.stopPropagation();
      if (mode !== 'view') return;
      resizeRef.current = {
          active: true,
          nodeId: node.id,
          startX: e.clientX,
          startY: e.clientY,
          initWidth: node.width || 180,
          initHeight: node.height || 80
      };
  }, [mode]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
        if (rafRef.current) return;
        rafRef.current = requestAnimationFrame(() => {
            if (dragRef.current.active && dragRef.current.nodeId) {
                const { startX, startY, initX, initY, nodeId } = dragRef.current;
                const dx = (e.clientX - startX) / scale;
                const dy = (e.clientY - startY) / scale;
                setNodes(prev => prev.map(n => n.id === nodeId ? { ...n, x: initX + dx, y: initY + dy } : n));
            }
            if (resizeRef.current.active && resizeRef.current.nodeId) {
                const { startX, startY, initWidth, initHeight, nodeId } = resizeRef.current;
                const dx = (e.clientX - startX) / scale;
                const dy = (e.clientY - startY) / scale;
                const newWidth = Math.max(100, initWidth + dx);
                const newHeight = Math.max(60, initHeight + dy);
                setNodes(prev => prev.map(n => n.id === nodeId ? { ...n, width: newWidth, height: newHeight } : n));
            }
            if (panRef.current.active) {
                const dx = e.clientX - panRef.current.startX;
                const dy = e.clientY - panRef.current.startY;
                setVisualOffset({ x: panRef.current.initOffsetX + dx, y: panRef.current.initOffsetY + dy });
            }
            rafRef.current = null;
        });
    };

    const handleMouseUp = async (e: MouseEvent) => {
        if (rafRef.current) cancelAnimationFrame(rafRef.current);
        rafRef.current = null;
        if (dragRef.current.active && dragRef.current.nodeId) {
            const nodeId = dragRef.current.nodeId;
            dragRef.current.active = false;
            const finalNode = nodes.find(n => n.id === nodeId);
            if (finalNode) await dbService.saveNode(finalNode);
        }
        if (resizeRef.current.active && resizeRef.current.nodeId) {
            const nodeId = resizeRef.current.nodeId;
            resizeRef.current.active = false;
            const finalNode = nodes.find(n => n.id === nodeId);
            if (finalNode) await dbService.saveNode(finalNode);
        }
        if (panRef.current.active) {
            panRef.current.active = false;
            setIsPanning(false);
        }
    };
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    return () => {
        if (rafRef.current) cancelAnimationFrame(rafRef.current);
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [nodes, scale]); 

  const renderConnections = () => {
    const lines = [];
    const getCenter = (n: FlowNode) => ({ x: n.x + (n.width || 180) / 2, y: n.y + (n.height || 80) / 2 });
    visibleNodes.forEach(source => {
        if (source.outgoingIds) {
            source.outgoingIds.forEach(targetId => {
                const target = visibleNodes.find(n => n.id === targetId);
                if (target) {
                    const start = getCenter(source);
                    const end = getCenter(target);
                    const dx = Math.abs(end.x - start.x);
                    const cp1 = { x: start.x + dx * 0.5, y: start.y };
                    const cp2 = { x: end.x - dx * 0.5, y: end.y };
                    if (Math.abs(end.y - start.y) > Math.abs(end.x - start.x)) {
                        cp1.x = start.x; cp1.y = start.y + 50;
                        cp2.x = end.x; cp2.y = end.y - 50;
                    }
                    lines.push(
                        <path key={`flow-${source.id}-${target.id}`} d={`M ${start.x} ${start.y} C ${cp1.x} ${cp1.y}, ${cp2.x} ${cp2.y}, ${end.x} ${end.y}`} stroke={isDark ? "#60a5fa" : "#3b82f6"} strokeWidth="3" fill="none" markerEnd="url(#arrowhead)" className="opacity-80 drop-shadow-sm" />
                    );
                }
            });
        }
    });
    return (
        <svg className="absolute top-0 left-0 w-full h-full pointer-events-none overflow-visible z-0">
            <defs><marker id="arrowhead" markerWidth="6" markerHeight="4" refX="6" refY="2" orient="auto"><polygon points="0 0, 6 2, 0 4" fill={isDark ? "#60a5fa" : "#3b82f6"} /></marker></defs>
            {lines}
        </svg>
    );
  };

  return (
    <div className="flex flex-col h-screen w-full relative bg-ios-light dark:bg-black overflow-hidden font-sans">
      {/* Top Bar (Hidden in Fullscreen) */}
      {!isFullScreen && (
          <div className="z-50 h-16 flex items-center justify-between px-6 bg-white/60 dark:bg-black/60 glass-panel border-b border-white/20 dark:border-white/10 backdrop-blur-xl shrink-0 transition-all">
            <div className="flex items-center gap-2">
              <button onClick={onBack} className="p-2 hover:bg-black/5 dark:hover:bg-white/10 rounded-full transition-colors"><ChevronLeft /></button>
              
              <div className="h-6 w-px bg-gray-300 dark:bg-zinc-700 mx-2"></div>
              
              <button onClick={handleGoRoot} className="p-2 hover:bg-black/5 dark:hover:bg-white/10 rounded-full transition-colors text-gray-700 dark:text-gray-300" title="回到根層級">
                 <Home size={20} />
              </button>
              
              <button 
                onClick={handleGoUp} 
                disabled={!viewRootId}
                className="p-2 hover:bg-black/5 dark:hover:bg-white/10 rounded-full transition-colors text-gray-700 dark:text-gray-300 disabled:opacity-30 disabled:cursor-not-allowed" 
                title="返回上一層"
              >
                 <ArrowUp size={20} />
              </button>
              
              <h2 className="ml-4 font-extrabold text-lg bg-clip-text text-transparent bg-gradient-to-r from-slate-900 to-slate-700 dark:from-white dark:to-slate-400">
                  {viewRootId ? nodes.find(n => n.id === viewRootId)?.label : project.name}
              </h2>
            </div>

            {/* Center Search Bar */}
             <div className="absolute left-1/2 -translate-x-1/2 w-[28rem] hidden md:flex flex-col z-50">
                <div className="flex bg-white/80 dark:bg-zinc-800/80 backdrop-blur-md rounded-2xl shadow-lg border border-white/40 dark:border-white/5 focus-within:ring-2 ring-purple-500/50 transition-all hover:scale-105">
                    <div className="flex items-center pl-4 text-gray-400">
                        <Search size={18}/>
                    </div>
                    <input type="text" className="w-full bg-transparent border-none focus:ring-0 px-3 py-2.5 text-sm dark:text-white placeholder:text-gray-400"
                        placeholder="搜尋節點..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} 
                    />
                </div>
                
                {/* Search Results Dropdown */}
                {searchQuery && (
                    <div className="mt-2 bg-white/95 dark:bg-zinc-900/95 backdrop-blur-xl rounded-2xl shadow-2xl border border-gray-200 dark:border-zinc-700 max-h-[400px] overflow-y-auto">
                        {filteredNodes.length === 0 ? (
                            <div className="p-4 text-center text-gray-400 text-sm">找不到相關節點</div>
                        ) : (
                            filteredNodes.map(node => (
                                <div 
                                    key={node.id}
                                    onClick={() => handleJumpToNode(node)}
                                    className="p-3 border-b border-gray-100 dark:border-zinc-800 hover:bg-blue-50 dark:hover:bg-blue-900/20 cursor-pointer flex justify-between items-center group transition-colors"
                                >
                                    <div className="flex flex-col">
                                        <span className="font-bold text-slate-800 dark:text-slate-200">{node.label}</span>
                                        <span className="text-xs text-gray-400 truncate max-w-[200px]">{node.description || '無描述'}</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <span className="text-[10px] font-mono bg-gray-100 dark:bg-zinc-700 text-gray-500 px-2 py-1 rounded-full">Level {node.level}</span>
                                        <ArrowUp size={14} className="text-gray-400 opacity-0 group-hover:opacity-100 rotate-45" />
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                )}
            </div>

            <div className="flex gap-3">
                 <button onClick={() => setAiChatOpen(true)} className="flex items-center gap-2 bg-gradient-to-r from-violet-500 to-fuchsia-500 text-white px-4 py-2 rounded-xl text-sm font-bold shadow-lg hover:brightness-110 active:scale-95 transition-all">
                    <Sparkles size={16} /><span className="hidden sm:inline">AI 詢問</span>
                 </button>
                 <button onClick={toggleTheme} className="p-2.5 text-gray-500 hover:bg-black/5 rounded-xl">{isDark ? <Sun size={20}/> : <Moon size={20}/>}</button>
            </div>
          </div>
      )}

      {/* Main Canvas */}
      <div 
        ref={canvasRef}
        className={`flex-1 relative overflow-hidden ${isPanning ? 'cursor-grabbing' : 'cursor-grab'} ${isLinking ? 'cursor-crosshair' : ''}`}
        onMouseDown={handleMouseDownCanvas}
        style={{
            backgroundImage: `radial-gradient(${isDark ? '#444' : '#ccc'} 1.5px, transparent 1.5px)`,
            backgroundSize: `${24 * scale}px ${24 * scale}px`,
            backgroundColor: isDark ? '#000' : '#F5F5F7',
            backgroundPosition: `${visualOffset.x}px ${visualOffset.y}px`
        }}
      >
         {/* Overlays */}
         {isLinking && <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-blue-500 text-white px-4 py-2 rounded-full shadow-lg z-40 text-sm font-bold animate-pulse">選擇連結目標</div>}
         {mode === 'batch_delete' && <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-red-500 text-white px-4 py-2 rounded-full shadow-lg z-40 text-sm font-bold animate-pulse">刪除模式：請選取要刪除的節點</div>}
         {mode === 'batch_edit' && <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-green-500 text-white px-4 py-2 rounded-full shadow-lg z-40 text-sm font-bold animate-pulse">文字編輯模式</div>}

         {/* Batch Delete Confirm Button */}
         {mode === 'batch_delete' && deleteCandidates.size > 0 && (
             <button 
                onClick={confirmBatchDelete}
                className="absolute bottom-32 left-1/2 -translate-x-1/2 bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-2xl shadow-xl z-50 font-bold text-lg flex items-center gap-2 animate-in slide-in-from-bottom-4"
             >
                 <Trash2 size={24} /> 刪除已選 ({deleteCandidates.size})
             </button>
         )}

         <div className="absolute top-0 left-0 w-full h-full will-change-transform origin-top-left" style={{ transform: `translate(${visualOffset.x}px, ${visualOffset.y}px) scale(${scale})` }}>
            {renderConnections()}
            {visibleNodes.map(node => (
                <Node 
                    key={node.id}
                    node={node}
                    mode={mode}
                    isEditing={editingNodeId === node.id} 
                    isSelected={selectedNode?.id === node.id}
                    isLinkSource={linkSourceId === node.id}
                    isSelectedForDelete={deleteCandidates.has(node.id)}
                    isFocus={viewRootId === node.id}
                    isParent={node.id === (nodes.find(n => n.id === viewRootId)?.parentId)}
                    onSelect={setSelectedNode}
                    onDragStart={handleDragNodeStart}
                    onResizeStart={handleResizeStart}
                    onDrillDown={handleDrillDown}
                    onGoUp={handleGoUp}
                    onDoubleClick={(n) => {
                         setEditingNodeId(n.id);
                    }}
                    onLabelChange={handleLabelChange}
                    onEditEnd={() => setEditingNodeId(null)} 
                    onToggleDeleteSelect={handleToggleDeleteSelect}
                />
            ))}
         </div>
      </div>

      {/* Collapsible Floating Toolbar (Bottom Right) */}
      <div className="absolute bottom-10 right-10 flex flex-col items-end gap-3 pointer-events-none z-50">
         
         {isToolsOpen && (
             <div className="pointer-events-auto flex flex-col gap-3 mb-2 items-end animate-in slide-in-from-bottom-4 fade-in duration-200">
                
                <div className="bg-white/90 dark:bg-zinc-800/90 glass-panel p-2 rounded-2xl shadow-xl border border-white/20 backdrop-blur-md flex flex-col gap-2">
                    <button onClick={toggleFullScreen} title="專注模式 (全螢幕)" className={`p-3 rounded-xl transition-colors ${isFullScreen ? 'bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600' : 'hover:bg-gray-100 dark:hover:bg-zinc-700'}`}>
                        {isFullScreen ? <Minimize size={20}/> : <Maximize size={20}/>}
                    </button>
                    <button onClick={toggleBatchEdit} title="文字編輯模式" className={`p-3 rounded-xl transition-colors ${mode === 'batch_edit' ? 'bg-green-100 dark:bg-green-900/30 text-green-600' : 'hover:bg-gray-100 dark:hover:bg-zinc-700'}`}>
                        <Edit3 size={20}/>
                    </button>
                    <button onClick={toggleBatchDelete} title="批量刪除模式" className={`p-3 rounded-xl transition-colors ${mode === 'batch_delete' ? 'bg-red-100 dark:bg-red-900/30 text-red-600' : 'hover:bg-gray-100 dark:hover:bg-zinc-700'}`}>
                        <Trash2 size={20}/>
                    </button>
                </div>

                {selectedNode && mode === 'view' && !editingNodeId && (
                    <div className="bg-white/90 dark:bg-zinc-800/90 glass-panel p-3 rounded-2xl shadow-xl border border-white/20 backdrop-blur-md flex flex-col gap-3 w-48">
                         <div className="flex justify-between items-center text-xs text-gray-500 font-bold px-1">
                             <span>編輯節點</span>
                         </div>
                         <div className="grid grid-cols-4 gap-2">
                             {NODE_COLORS.map(color => (
                                <button key={color} onClick={() => selectedNode && handleUpdateNode({...selectedNode, color})} className="w-6 h-6 rounded-full border border-white/20 shadow-sm hover:scale-125 transition-transform" style={{ backgroundColor: color }} />
                             ))}
                         </div>
                         <div className="flex gap-2">
                            <button onClick={() => { setIsLinking(true); setLinkSourceId(selectedNode.id); setMode('view'); }} className="flex-1 bg-blue-50 dark:bg-blue-900/20 text-blue-600 py-2 rounded-lg text-xs font-bold hover:bg-blue-100 flex justify-center items-center gap-1">
                                <LinkIcon size={14}/> 連結
                            </button>
                            <button onClick={handleDeleteSingleNode} className="flex-1 bg-red-50 dark:bg-red-900/20 text-red-600 py-2 rounded-lg text-xs font-bold hover:bg-red-100 flex justify-center items-center gap-1">
                                <Trash2 size={14}/> 刪除
                            </button>
                         </div>
                    </div>
                )}

                <div className="bg-white/90 dark:bg-zinc-800/90 glass-panel p-1.5 rounded-xl shadow-lg border border-white/20 backdrop-blur-md flex flex-col gap-1">
                    <button onClick={() => setScale(s => Math.min(s + 0.1, 2))} className="p-2 hover:bg-gray-100 dark:hover:bg-zinc-700 rounded-lg"><ZoomIn size={18}/></button>
                    <button onClick={() => setScale(s => Math.max(s - 0.1, 0.5))} className="p-2 hover:bg-gray-100 dark:hover:bg-zinc-700 rounded-lg"><ZoomOut size={18}/></button>
                    <div className="w-full h-px bg-gray-200 dark:bg-zinc-700 my-1"></div>
                    <button onClick={handleResetZoom} className="p-2 hover:bg-gray-100 dark:hover:bg-zinc-700 rounded-lg text-blue-500" title="重置視角"><Focus size={18}/></button>
                </div>
             </div>
         )}

         <div className="pointer-events-auto flex items-center gap-3">
            <button 
                onClick={() => setIsToolsOpen(!isToolsOpen)}
                className={`w-14 h-14 rounded-full shadow-lg flex items-center justify-center transition-all hover:scale-105 active:scale-95 ${isToolsOpen ? 'bg-white dark:bg-zinc-700 text-gray-800 dark:text-white' : 'bg-gray-100 dark:bg-zinc-800 text-gray-600 dark:text-gray-300'}`}
            >
                {isToolsOpen ? <X size={24}/> : <Menu size={24}/>}
            </button>
            <button 
                onClick={handleAddNode}
                className="w-16 h-16 bg-gradient-to-br from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded-[24px] shadow-2xl shadow-blue-500/40 flex items-center justify-center transition-transform hover:scale-110 active:scale-90"
            >
                <Plus size={32} strokeWidth={3} />
            </button>
         </div>
      </div>

      {/* AI Chat Modal */}
      {aiChatOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/20 backdrop-blur-sm">
            <div className="bg-white dark:bg-zinc-900 w-full max-w-lg rounded-2xl shadow-2xl border border-white/20 p-6 animate-in zoom-in-95 mx-4">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-bold flex items-center gap-2 bg-gradient-to-r from-violet-500 to-fuchsia-500 bg-clip-text text-transparent">
                        <Sparkles className="text-fuchsia-500" size={20} /> AI 專案顧問
                    </h3>
                    <button onClick={() => setAiChatOpen(false)} className="p-2 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-full transition-colors"><X size={20}/></button>
                </div>
                
                <div className="h-64 overflow-y-auto bg-gray-50 dark:bg-zinc-950/50 rounded-xl p-4 mb-4 border border-gray-100 dark:border-zinc-800 whitespace-pre-wrap text-sm leading-relaxed scroll-smooth">
                    {isAiLoading ? (
                        <div className="flex items-center justify-center h-full text-gray-500 gap-2 animate-pulse">
                            <Bot size={20}/> 正在分析流程結構...
                        </div>
                    ) : aiResponse ? (
                        <div className="prose dark:prose-invert text-sm">{aiResponse}</div>
                    ) : (
                        <div className="flex flex-col items-center justify-center h-full text-gray-400 gap-2">
                             <Sparkles size={32} className="opacity-20"/>
                             <p>請問我關於此專案流程的建議，<br/>我會分析目前的節點結構並給予回答。</p>
                        </div>
                    )}
                </div>

                <div className="flex gap-2">
                    <input 
                        autoFocus
                        className="flex-1 bg-white dark:bg-zinc-800 border border-gray-200 dark:border-zinc-700 rounded-xl px-4 py-3 focus:ring-2 ring-fuchsia-500 focus:outline-none transition-all shadow-sm"
                        placeholder="例如：這個流程有什麼缺漏？"
                        value={aiQuery}
                        onChange={(e) => setAiQuery(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleAskAi()}
                    />
                    <button 
                        onClick={handleAskAi}
                        disabled={!aiQuery.trim() || isAiLoading}
                        className="bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 text-white px-5 py-2 rounded-xl font-bold disabled:opacity-50 transition-all shadow-md active:scale-95 flex items-center justify-center"
                    >
                        {isAiLoading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"/> : <Send size={20}/>}
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};