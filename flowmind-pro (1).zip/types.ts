export interface Project {
  id: string;
  name: string;
  description: string;
  createdAt: number;
  thumbnail?: string; // Base64 placeholder or color
}

export enum NodeType {
  ROOT = 'ROOT',
  PROCESS = 'PROCESS',
  DECISION = 'DECISION',
  NOTE = 'NOTE',
}

export interface FlowNode {
  id: string;
  projectId: string;
  parentId: string | null; // null if it's the absolute root of the project
  outgoingIds?: string[]; // IDs of sibling nodes this node connects to (Flow logic)
  label: string;
  description?: string;
  type: NodeType;
  level: number; // 0 to 9 (10 layers max)
  x: number;
  y: number;
  width?: number;
  height?: number;
  color?: string;
  fontSize?: number;
  collapsed?: boolean;
}

export interface AppState {
  currentProject: Project | null;
  theme: 'light' | 'dark';
}

export interface SearchResult {
  nodeId: string;
  label: string;
  path: string[]; // Names of parents
}