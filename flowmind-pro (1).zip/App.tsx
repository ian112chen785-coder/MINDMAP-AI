import React, { useState, useEffect } from 'react';
import { ProjectList } from './components/ProjectList';
import { MapEditor } from './components/MapEditor';
import { Project } from './types';
import { dbService } from './services/dbService';

const App: React.FC = () => {
  const [currentProject, setCurrentProject] = useState<Project | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  useEffect(() => {
    loadProjects();
    // Check system preference
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      setTheme('dark');
    }
  }, []);

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const loadProjects = async () => {
    try {
      const data = await dbService.getProjects();
      setProjects(data);
    } catch (e) {
      console.error("DB Error", e);
    }
  };

  const handleCreateProject = async (name: string, desc: string) => {
    const newProject: Project = {
      id: crypto.randomUUID(),
      name,
      description: desc,
      createdAt: Date.now()
    };
    await dbService.addProject(newProject);
    setProjects(prev => [...prev, newProject]);
  };

  const handleDeleteProject = async (id: string) => {
    await dbService.deleteProject(id);
    setProjects(prev => prev.filter(p => p.id !== id));
  };

  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  };

  return (
    <div className="w-full h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 dark:from-zinc-950 dark:via-black dark:to-zinc-900 text-slate-900 dark:text-white transition-colors duration-500">
      {currentProject ? (
        <MapEditor 
          project={currentProject} 
          onBack={() => setCurrentProject(null)}
          toggleTheme={toggleTheme}
          isDark={theme === 'dark'}
        />
      ) : (
        <ProjectList 
          projects={projects} 
          onOpen={setCurrentProject} 
          onCreate={handleCreateProject}
          onDelete={handleDeleteProject}
        />
      )}
    </div>
  );
};

export default App;